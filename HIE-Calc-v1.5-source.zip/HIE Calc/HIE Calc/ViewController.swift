//
//  ViewController.swift
//  HIE Calc
//
//  Created by Rohini Vivek on 2017-07-02.
//  Copyright © 2017 Rohini Vivek. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

   
    @IBOutlet var sixHoursInd: UISwitch!
    @IBOutlet var ApgarInd: UISwitch!
    @IBOutlet var BaseExcessInd: UISwitch!
    @IBOutlet var IPPVInd: UISwitch!
    @IBOutlet var CordPHInd: UISwitch!
    @IBOutlet var ConsciousnessInd: UISwitch!
    @IBOutlet var SpontaneousActivityInd: UISwitch!
    @IBOutlet var PostureInd: UISwitch!
    @IBOutlet var ToneInd: UISwitch!
    @IBOutlet var ReflexInd: UISwitch!
    
    @IBOutlet var PupilInd: UISwitch!
    @IBOutlet var BradyCardiaInd: UISwitch!
    @IBOutlet var ApneaInd: UISwitch!
    
    @IBOutlet var SeizureInd: UISwitch!

    override func viewDidAppear(_ animated: Bool) {
        displayDisclaimer()
    }
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    @IBAction func mouseTouchDown(_ sender: Any) {
        if isYes(){
            displayYesMessage()
        }else{
            displayNoMessage()
        }
    }
    
    @IBAction func gestAge(_ sender: Any) {
        
    }
    
    // MARK: - Result colours (traffic light). Custom RGB for iOS 10.3 compatibility.
    let qualifyColor   = UIColor(red: 0.80, green: 0.0,  blue: 0.0,  alpha: 1.0) // red   = qualifies
    let borderlineColor = UIColor(red: 0.85, green: 0.55, blue: 0.0, alpha: 1.0) // amber = A met, not B
    let noQualifyColor = UIColor(red: 0.0,  green: 0.55, blue: 0.15, alpha: 1.0) // green = does not qualify

    // MARK: - Guidance statements

    let gaStatement = "Therapeutic hypothermia is not recommended in infants born less than 35 weeks\u{2019} gestational age. There is limited evidence regarding the safety and effectiveness of therapeutic hypothermia for neonates born at 35 0/7 to 35 6/7 weeks\u{2019} gestation; it may be considered in discussion of potential risks and benefits with families."

    let ageStatement = "Initiation of hypothermia between 6 and 24 hours after birth, in infants who did not initially meet criteria or were unable to have therapeutic hypothermia initiated in the first 6 hours after birth, may be considered after discussion with the parent or guardian of possible benefit and associated risk."

    // MARK: - Criteria evaluation

    // Criteria A: at least one metabolic / resuscitation marker
    func metabolicMet() -> Bool {
        return ApgarInd.isOn || BaseExcessInd.isOn || IPPVInd.isOn || CordPHInd.isOn
    }

    // Criteria B: seizure, or more than two encephalopathy signs
    func encephalopathyMet() -> Bool {
        var i = 0
        if ConsciousnessInd.isOn {i += 1}
        if SpontaneousActivityInd.isOn {i += 1}
        if PostureInd.isOn {i += 1}
        if ToneInd.isOn {i += 1}
        if ReflexInd.isOn {i += 1}
        if PupilInd.isOn || BradyCardiaInd.isOn || ApneaInd.isOn {i += 1}
        return SeizureInd.isOn || i > 2
    }

    // Everything except the gestational-age and 6-hour gates
    func meetsCoreCriteria() -> Bool {
        return metabolicMet() && encephalopathyMet()
    }

    func  isYes() -> Bool{
        return gestAgeInd.isOn && sixHoursInd.isOn && meetsCoreCriteria()
    }

    
    @IBOutlet var gestAgeInd: UISwitch!
    
    func displayDisclaimer(){
        
        /*let txt = "Does not satisfy criteria for therapeutic hypothermia \n Hi "
        
        let alertController = UIAlertController(title: "Disclaimer", message:
            txt, preferredStyle: UIAlertControllerStyle.alert)
        alertController.addAction(UIAlertAction(title: "Agree", style: UIAlertActionStyle.default,handler: nil))
        
        self.present(alertController, animated: true, completion: nil)*/
 
        let txt = "Please read the following disclaimer before proceeding with use of the HIE calculator Mobile Application. \n\nThe purpose of this Application is to make cooling criteria more accessible and easy to use. It DOES NOT replace clinical judgement and assessment.\n\nThis calculator is based on the American Academy of Pediatrics (AAP) clinical report: Zanelli SA, Wusthoff CJ, Lucke AM, Kaufman DA; Committee on Fetus and Newborn; Section on Neurology. Therapeutic Hypothermia for Neonatal Hypoxic-Ischemic Encephalopathy: Clinical Report. Pediatrics. 2026;157(2):e2025073627.\n\nBy using this Application you hereby waive any claims, causes of action and demands, whether in tort or contract, against the developer (including its employees, directors and agents) in any way related to use of the Application and the information derived from it.\n\nThe developer is not responsible for any decision made using this application. \n\n  The Application is provided  as-is with no representations or warranties of any kind, express, statutory or implied, as to the operation of the Application, or the information, content, materials, or products included on the Application. To the fullest extent permissible by applicable law, the developer and its officers, directors, employees and contractors disclaim all warranties, express, statutory, or implied, including, but not limited to, implied warranties of merchantability, fitness for a particular purpose or non-infringement.\n\nThe developer does not warrant that all aspects of the Application will be available at any time or from any particular location, will be secure or error-free, that defects will be corrected, or that the Application is free of viruses or other potentially harmful components.\n\nI agree to the above Terms of Use for the HIE cooling calculator Application."
        
        
        let alertController = UIAlertController(title: "Disclaimer", message: txt, preferredStyle: .alert)
        let OKAction = UIAlertAction(title: "Agree", style: .cancel) { (action) in
            alertController.dismiss(animated: true, completion: nil)
        }
        alertController.addAction(OKAction)
        
        let paragraphStyle = NSMutableParagraphStyle()
        paragraphStyle.alignment = NSTextAlignment.left
        
        let messageText = NSMutableAttributedString(
            string: txt,
            attributes: [
                NSAttributedString.Key.paragraphStyle: paragraphStyle,
                NSAttributedString.Key.font: UIFont.systemFont(ofSize: 13.0)
            ]
        )
        
        alertController.setValue(messageText, forKey: "attributedMessage")
        self.present(alertController, animated: true, completion: nil)
        
        
        
    }
    
    
    
    
    
    
    
    func displayNoMessage(){

        let gaOff = !gestAgeInd.isOn
        let ageOff = !sixHoursInd.isOn
        let aMet = metabolicMet()
        let bMet = encephalopathyMet()

        // Amber: Criteria A met but not Criteria B -> does not qualify, recommend serial exams.
        let borderline = aMet && !bMet

        var verdict: String
        var verdictColor: UIColor
        var txt = "Does not satisfy criteria for therapeutic hypothermia."

        if borderline {
            verdict = "  DOES NOT QUALIFY \u{2014} REASSESS  "
            verdictColor = borderlineColor
            txt += "\n\nCriteria A is met but Criteria B is not. The infant does not currently qualify for therapeutic hypothermia. Serial neurological examinations are recommended to reassess for evolving encephalopathy."
        } else {
            verdict = "  DOES NOT QUALIFY  "
            verdictColor = noQualifyColor
        }

        if gaOff {
            txt += "\n\nThe infant does not meet the gestational age criterion (\u{2265} 36 weeks).\n\n" + gaStatement
        }

        if ageOff {
            txt += "\n\nThe infant is more than 6 hours from birth.\n\n" + ageStatement
        }

        // Offer an override only when a gate (GA or > 6 hours) is the sole barrier,
        // i.e. Criteria A and B are both met. If A or B is not met, no override.
        presentResult(title: "Result", verdict: verdict, color: verdictColor,
                      message: txt, allowOverride: (gaOff || ageOff) && aMet && bMet)
    }

    func displayOverrideResult(){

        let gaOff = !gestAgeInd.isOn
        let ageOff = !sixHoursInd.isOn

        var reasons: [String] = []
        if gaOff { reasons.append("gestational age (< 36 weeks)") }
        if ageOff { reasons.append("age (> 6 hours from birth)") }
        let reasonText = reasons.joined(separator: " and ")

        let aMet = metabolicMet()
        let bMet = encephalopathyMet()

        var verdict: String
        var verdictColor: UIColor
        var txt: String

        if aMet && bMet {
            verdict = "  QUALIFIES (CRITERIA A + B)  "
            verdictColor = qualifyColor
            txt = "Based on Criteria A + B, the infant SATISFIES the criteria for therapeutic hypothermia."
        } else if aMet && !bMet {
            verdict = "  DOES NOT QUALIFY \u{2014} REASSESS  "
            verdictColor = borderlineColor
            txt = "Based on Criteria A + B, the infant does not currently satisfy the criteria. Criteria A is met but Criteria B is not; serial neurological examinations are recommended to reassess for evolving encephalopathy."
        } else {
            verdict = "  DOES NOT QUALIFY (CRITERIA A + B)  "
            verdictColor = noQualifyColor
            txt = "Based on Criteria A + B, the infant DOES NOT satisfy the criteria for therapeutic hypothermia."
        }

        txt += "\n\nCriteria A (metabolic / resuscitation): " + (aMet ? "met" : "not met")
        txt += "\nCriteria B (encephalopathy): " + (bMet ? "met" : "not met")

        txt += "\n\nThis override sets aside the \(reasonText) criterion. Use clinical judgement together with the guidance below:"
        if gaOff { txt += "\n\n" + gaStatement }
        if ageOff { txt += "\n\n" + ageStatement }

        presentResult(title: "Override", verdict: verdict, color: verdictColor,
                      message: txt, allowOverride: false)
    }

    func displayYesMessage(){
        presentResult(title: "Result",
                      verdict: "  QUALIFIES FOR THERAPEUTIC HYPOTHERMIA  ",
                      color: qualifyColor,
                      message: "Satisfies criteria for therapeutic hypothermia. The qualifying criteria, Criteria A and Criteria B are all met.",
                      allowOverride: false)
    }

    // Shared alert presenter. The verdict is shown as a centred, colour-filled
    // banner above the detail text, so the result stands out at a glance.
    func presentResult(title: String, verdict: String, color: UIColor, message txt: String, allowOverride: Bool){

        let full = verdict + "\n\n" + txt

        let alertController = UIAlertController(title: title, message:
            full, preferredStyle: UIAlertController.Style.alert)

        if allowOverride {
            alertController.addAction(UIAlertAction(title: "Override", style: UIAlertAction.Style.default) { (action) in
                self.displayOverrideResult()
            })
        }

        alertController.addAction(UIAlertAction(title: "Dismiss", style: UIAlertAction.Style.cancel, handler: nil))

        let paragraphStyle = NSMutableParagraphStyle()
        paragraphStyle.alignment = NSTextAlignment.left

        let messageText = NSMutableAttributedString(
            string: full,
            attributes: [
                NSAttributedString.Key.paragraphStyle: paragraphStyle,
                NSAttributedString.Key.font: UIFont.systemFont(ofSize: 13.0)
            ]
        )

        // Highlight the verdict: white bold text on a solid red / amber / green band.
        let bannerStyle = NSMutableParagraphStyle()
        bannerStyle.alignment = NSTextAlignment.center
        bannerStyle.lineSpacing = 4.0

        let verdictRange = NSRange(location: 0, length: (verdict as NSString).length)
        messageText.addAttributes(
            [
                NSAttributedString.Key.backgroundColor: color,
                NSAttributedString.Key.foregroundColor: UIColor.white,
                NSAttributedString.Key.font: UIFont.boldSystemFont(ofSize: 15.0),
                NSAttributedString.Key.paragraphStyle: bannerStyle
            ],
            range: verdictRange
        )

        alertController.setValue(messageText, forKey: "attributedMessage")
        self.present(alertController, animated: true, completion: nil)
    }


}

